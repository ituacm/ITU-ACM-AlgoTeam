(() => {
    const mergedLink = "https://raw.githubusercontent.com/ituacm/ITU-ACM-22-Summer-Algorithm-Team-Bootcamp/main/Regular-Question-Answers/~merged.txt";
    const toBeMergedLink = "https://raw.githubusercontent.com/ituacm/ITU-ACM-22-Summer-Algorithm-Team-Bootcamp/main/Regular-Question-Answers/~toBeMerged.txt";
    const githubMirror = "https://github.com/ituacm/ITU-ACM-22-Summer-Algorithm-Team-Bootcamp/blob/main/Regular-Question-Answers/"
    let currentProblem = ""
    let leetcodeTitle;

    var getMergedList = (async () => {
        const response = await fetch(mergedLink);
        const text = await response.text();
        list = text.split("\n");
        return list;
      })()
      
      var getToBeMergedList = (async () => {
        const response = await fetch(toBeMergedLink);
        const text = await response.text();
        list = text.split("\n");
        return list;
      })()

    chrome.runtime.onMessage.addListener((obj, sender, response) => {
        const {type, value, problemLink} = obj;
        if (type === "NEW") {
            currentProblem = problemLink;
            setTimeout(newProblemLoaded, 1000);
        }    
    })
    document.onreadystatechange = function () {
        if (document.readyState == "complete") {
            console.log("Now loaded");
            currentProblem = window.location.href;
            console.log(currentProblem);
            setTimeout(newProblemLoaded, 2000);
        }
    }

    function placeIcon(iconIndex){
        console.log(iconIndex + " is the index")
        iconImgSource = "";
        iconTitle = "";
        iconClass = "";
        iconMarginLeft = "0.4em";
        switch (iconIndex) {
            case 0:
                iconImgSource = "img/close.png";
                iconTitle = "This problem does not have an editorial";
                iconClass = "nonavailable";
                break;
            case 1:
                iconImgSource = "img/hourglass.png";
                iconTitle = "Editorial is being prepared";
                iconClass = "inprogress";
                iconMarginLeft = "0.3em";
                break;
            case 2:
                iconImgSource = "img/check.png";
                iconTitle = "Click for editorial";
                iconClass = "available";
                break;
        }
        
        const icon = document.createElement("img");
        icon.src = chrome.runtime.getURL(iconImgSource);
        icon.className = "status-icon " + iconClass;
        icon.title = iconTitle;
        icon.style.width = "1em";
        icon.style.marginLeft = iconMarginLeft;
        icon.style.marginBottom = "0.2em";
        if (iconIndex == 2)
            icon.addEventListener("click", function () {
                editorialLink = currentProblem.substring(30);
                editorialLink = editorialLink.slice(0, -1);
                editorialLink = githubMirror + editorialLink + ".cpp/";
                window.open(editorialLink);
            });

        leetcodeTitle = document.getElementsByClassName("css-v3d350")[0];
        leetcodeTitle.appendChild(icon);
    }

    const newProblemLoaded = () => {
        var iconIndex = 0;
        getMergedList.then(function(result) {
            var isFound = result.find(function(element) {
              return element == currentProblem;
            })
            console.log(isFound != undefined);
            if (isFound) iconIndex = 2;
        })
          
        getToBeMergedList.then(function(result) {
            var isFound = result.find(function(element) {
              return element == currentProblem;
            })
            console.log(isFound != undefined);
            if (isFound) iconIndex = 1;
        })

        setTimeout(function() {
            placeIcon(iconIndex);
          }, 1000)
        //const iconExists = document.getElementsByClassName("status-icon")[0];

            //alert(currentProblem);
        /*const icon = document.createElement("img"), ic2 = document.createElement("img"), ic3 = document.createElement("img");
        icon.src = chrome.runtime.getURL("img/close.png");
        icon.className = "non-available "+"status-icon";
        icon.title = "This problem does not have an editorial";
        icon.style.width = "1em";
        icon.style.marginLeft = "0.5em";
        icon.style.marginBottom = "0.2em";
        
        ic2.src = chrome.runtime.getURL("img/check.png");
        ic2.className = "available "+"status-icon";
        ic2.title = "Click for editorial";
        ic2.style.width = "1em";
        ic2.style.marginLeft = "0.5em";
        ic2.style.marginBottom = "0.2em";

        ic3.src = chrome.runtime.getURL("img/hourglass.png");
        ic3.className = "in-progress "+"status-icon";
        ic3.title = "Editorial is being prepared";
        ic3.style.width = "1em";
        ic3.style.marginLeft = "0.5em";
        ic3.style.marginBottom = "0.2em";

        leetcodeTitle = document.getElementsByClassName("css-v3d350")[0];
        leetcodeTitle.appendChild(icon);
        leetcodeTitle.appendChild(ic2);

        leetcodeTitle.appendChild(ic3);*/
        
    }
})();

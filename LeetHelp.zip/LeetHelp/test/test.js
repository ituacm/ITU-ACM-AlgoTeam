const mergedLink = "https://raw.githubusercontent.com/ituacm/ITU-ACM-22-Summer-Algorithm-Team-Bootcamp/main/Regular-Question-Answers/~merged.txt";
const toBeMergedLink = "https://raw.githubusercontent.com/ituacm/ITU-ACM-22-Summer-Algorithm-Team-Bootcamp/main/Regular-Question-Answers/~toBeMerged.txt";

const currentLink = "https://leetcode.com/problems/add-binary";

var getMergedList = (async () => {
  const response = await fetch(mergedLink);
  const text = await response.text();
  list = text.split("\n");
  return list;
})()

var getToBeMergedList = (async () => {
  const response = await fetch(toBeMergedLink);
  const text = await response.text();
  list = text.split("\n");
  return list;
})()

var icon = 0;

getMergedList.then(function(result) {
  var isFound = result.find(function(element) {
    return element == currentLink;
  })
  console.log(isFound != undefined);
  if (isFound) icon = 2;
})

getToBeMergedList.then(function(result) {
  var isFound = result.find(function(element) {
    return element == currentLink;
  })
  console.log(isFound != undefined);
  if (isFound) icon = 1;

})

setTimeout(function() {
  console.log(icon);
}, 1000)
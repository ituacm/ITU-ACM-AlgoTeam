Thank you for downloading LeetHelp Google Chrome extension. For installation follow the steps below:

1. Unzip the "LeetHelp" folder
2. Open Chrome and go to "Settings"
3. Click on "Extensions"
4. Turn on the "Developer mode" in the top-right corner
5. Click "Load unpacked" in the top-left corner and select the unzipped "LeetHelp" folder

Congratulations! Now while browsing problems on leetcode.com you are able access the available solutions by clicking the icon next to the problem name. 

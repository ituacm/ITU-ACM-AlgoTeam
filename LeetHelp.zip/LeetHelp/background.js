chrome.tabs.onUpdated.addListener((tabId, tab) => {
    if (tab.url && tab.url.includes("leetcode.com/problems")) {
      chrome.tabs.sendMessage(tabId, {
        type: "NEW",
        problemLink: tab.url
      });
    }
  });
  